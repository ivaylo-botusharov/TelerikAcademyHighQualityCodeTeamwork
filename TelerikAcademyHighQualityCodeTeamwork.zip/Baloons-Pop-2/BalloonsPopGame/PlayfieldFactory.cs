﻿namespace BalloonsPop
{
    public abstract class PlayfieldFactory
    {
        public abstract Playfield CreatePlayfield();
    }
}
