﻿namespace BalloonsPop
{
    public class Program
    {
        public static void Main()
        {
            Game.Instance.Start();
        }
    }
}
